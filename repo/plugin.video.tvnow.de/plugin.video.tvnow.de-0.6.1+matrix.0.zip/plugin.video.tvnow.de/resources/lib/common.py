import urllib.parse as ul
import xbmcaddon
import xbmc
import json

base_url = "plugin://" + xbmcaddon.Addon().getAddonInfo('id')

def build_url(query):
    return base_url + '?' + ul.urlencode(query)

# Get installed inputstream addon
def getInputstreamAddon():
    is_types = ['inputstream.adaptive', 'inputstream.smoothstream']
    for i in is_types:
        r = xbmc.executeJSONRPC(
            '{"jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails", '
            + '"params": {"addonid":"' + i + '", "properties": ["enabled"]}}')
        data = json.loads(r)
        if not "error" in data.keys():
            if data["result"]["addon"]["enabled"] == True:
                return i
    return None