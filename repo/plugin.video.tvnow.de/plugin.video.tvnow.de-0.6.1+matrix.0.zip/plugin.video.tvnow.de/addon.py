#!/usr/bin/python
# -*- coding: utf-8 -*-
import sys
import urllib.parse as urlparse
#import resources.lib.vod as vod
from resources.lib.navigation import Navigation
#from resources.lib.database import Database
import xbmcaddon
import xbmcvfs

addon_handle = int(sys.argv[1])
plugin_base_url = sys.argv[0]
params = dict(urlparse.parse_qsl(sys.argv[2][1:]))
addon = xbmcaddon.Addon()
"""datapath = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
dbPath = datapath + 'Database'
db = Database()
if not os.path.isdir(datapath):
    os.mkdir(datapath)
if os.path.isfile(dbPath):
    with open(dbPath, 'rb') as f:
        try:
            db = pickle.load(f)
        except:
            print ("Invalid File")
if db.updateDatabase():
    with open(dbPath, "wb") as f:
        pickle.dump(db,f)"""

nav = Navigation(None)
# Router for all plugin actions
if params:
    if params['action'] == 'playVod':
        nav.playVOD(params['id'])
    elif params['action'] == 'listPage':
        nav.listSeasonsFromSeries(params['id'])
    elif params['action'] == 'listSeason':
        nav.listEpisodesFromSeason(params['season_id'])
    elif params['action'] == 'showMovie':
        nav.showMovie(params['id'])
    elif params['action'] == 'listLive':
        nav.listLiveTV()
    elif params['action'] == 'listEvents':
        nav.listEvents()
    elif params['action'] == 'overview':
        nav.listOverview(params['id'])
    elif params['action'] == 'login':
        nav.login()
    elif params['action'] == 'logout':
        nav.logout()
    elif params['action'] == 'search':
        nav.search()
    elif params['action'] == 'recommendation':
        nav.recommendationOverview()
    elif params['action'] == 'listRecommendation':
        nav.listRecommendation(params['id'])
else:
    nav.rootDir()