# Kodi 18+ module port of MechanicalSoup

![MechanicalSoup. A Python library for automating website interaction.](https://raw.githubusercontent.com/MechanicalSoup/MechanicalSoup/master/assets/mechanical-soup-logo.png)

Home page: https://mechanicalsoup.readthedocs.io/

GitHub repo: https://github.com/MechanicalSoup/MechanicalSoup
